package unit7.gui;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import unit7.controllers.CourseController;
import unit7.models.Course;
import unit7.utils.ValidationUtils;

/**
 * Course panel class - represents a course panel with form and table layout and
 * design and functionality
 */
public class CoursePanel extends BasePanel<Course> {
    private CourseController courseController;
    private TextField idField, courseNameField;
    private Button addButton, updateButton, deleteButton, clearButton;

    /**
     * Constructor for CoursePanel
     * 
     * @param controller the course controller
     */
    public CoursePanel(CourseController controller) {
        this.courseController = controller;
        initializePanel(); // Initialize form elements
        initializeFormLayout(); // Setup form layout
        initializeTableLayout(); // Setup table layout
        refreshTable(); // Refresh table data
    }

    /**
     * override setupForm method from BasePanel class to setup form elements and add
     * them to the form layout
     */
    @Override
    protected void setupForm() {
        // Setup form elements

        // the id field is not editable by the user and is used to display the id of the
        // selected course
        idField = new TextField();
        idField.setEditable(false);
        courseNameField = new TextField();
        addButton = new Button("Add Course");
        updateButton = new Button("Update Course");
        deleteButton = new Button("Delete Course");
        clearButton = new Button("Clear Selection");

        // set the actions for the buttons
        addButton.setOnAction(e -> addCourse());
        updateButton.setOnAction(e -> updateCourse());
        deleteButton.setOnAction(e -> deleteCourse());
        clearButton.setOnAction(e -> clearSelection());

        // Add form elements to the form layout
        form.setVgap(10);
        form.setHgap(10);
        form.setPadding(new Insets(20));
        form.add(new Label("ID:"), 0, 0);
        form.add(idField, 1, 0);
        form.add(new Label("Course Name:"), 0, 1);
        form.add(courseNameField, 1, 1);
        form.add(addButton, 0, 2);
        form.add(updateButton, 1, 2);
        form.add(deleteButton, 2, 2);
        form.add(clearButton, 3, 2);
    }

    /**
     * override setupTable method from BasePanel class to setup table columns and
     * add them to the table view
     */
    @Override
    protected void setupTable() {
        // Setup table columns
        addTableColumn("ID", "id");
        addTableColumn("Course Name", "courseName");

        // register the setOnMouseClicked event handler for the table
        table.setOnMouseClicked(e -> selectCourse());
    }

    /**
     * override refreshTable method from BasePanel class to refresh the table data
     */
    @Override
    protected void refreshTable() {
        table.getItems().setAll(courseController.getCourses());
    }

    /**
     * Clear the selection
     */
    private void clearSelection() {
        table.getSelectionModel().clearSelection();
        idField.clear();
        courseNameField.clear();
    }

    /**
     * Add a course
     */
    private void addCourse() {
        if (!validateInput())
            return;
        Course newCourse = new Course(courseNameField.getText());
        courseController.addCourse(newCourse);
        refreshTable();
    }

    /**
     * Update a course
     */
    private void updateCourse() {
        Course selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            // if no course is selected, show an alert
            ValidationUtils.showAlert("Please select a course to update.");
            return;
        }
        if (!validateInput()) {
            // if the input is not valid, return without updating the course
            return;
        }

        selected.setCourseName(courseNameField.getText());
        courseController.updateCourse(selected);
        refreshTable();
    }

    /**
     * Delete a course
     */
    private void deleteCourse() {
        Course selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            // if no course is selected, show an alert
            ValidationUtils.showAlert("Please select a course to delete.");
            return;
        }
        if (ValidationUtils.confirmAction("Are you sure you want to delete this course?")) {
            // if the user confirms the action, delete the course
            courseController.deleteCourse(selected);
            refreshTable();
        }
    }

    /**
     * Validate the input
     * 
     * @return true if the input is valid, false otherwise
     */
    private boolean validateInput() {
        if (!ValidationUtils.isNotEmpty(courseNameField.getText())) {
            // if the course name is empty, show an alert
            ValidationUtils.showAlert("Course name cannot be empty.");
            return false;
        }
        return true;
    }

    /**
     * Select a course
     */
    private void selectCourse() {
        Course selected = table.getSelectionModel().getSelectedItem();
        if (selected != null) {
            // if a course is selected, set the id and course name fields to the selected
            idField.setText(String.valueOf(selected.getId()));
            courseNameField.setText(selected.getCourseName());
        }
    }
}
