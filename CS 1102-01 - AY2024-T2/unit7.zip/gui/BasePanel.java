package unit7.gui;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

/**
 * Base panel class - represents a base panel with shared properties and methods
 * and design
 */
public abstract class BasePanel<T> extends VBox {

    protected TableView<T> table;
    protected GridPane form;

    /**
     * Constructor for BasePanel
     */
    public BasePanel() {
        table = new TableView<>();
        form = new GridPane();
        setupTable();
    }

    protected abstract void setupForm();

    protected abstract void setupTable();

    protected abstract void refreshTable();

    /**
     * Add a table column to the table view with the specified column name and model
     * property name
     * 
     * @param columnName the name of the column
     * @param property   the name of the model property
     */
    protected void addTableColumn(String columnName, String property) {
        TableColumn<T, String> column = new TableColumn<>(columnName);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        table.getColumns().add(column);
    }

    /**
     * Initialize the form layout and add it to the panel
     */
    protected void initializeFormLayout() {
        form.setVgap(10);
        form.setHgap(10);
        this.getChildren().add(form);
    }

    /**
     * Initialize the panel
     */
    protected void initializePanel() {
        setupForm();
    }

    /**
     * Initialize the table layout and add it to the panel
     */
    protected void initializeTableLayout() {
        VBox.setVgrow(table, Priority.ALWAYS);
        this.getChildren().add(table);
    }
}
