package unit7.gui;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import unit7.controllers.StudentController;
import unit7.models.Student;
import unit7.utils.ValidationUtils;

/**
 * Student panel class - represents a student panel with form and table layout
 * and
 * design and functionality
 */
public class StudentPanel extends BasePanel<Student> {

    private StudentController studentController;
    private TextField idField, nameField, emailField;
    private Button addButton, updateButton, deleteButton, clearButton;

    /**
     * Constructor for StudentPanel
     * 
     * @param controller the student controller
     */
    public StudentPanel(StudentController controller) {
        this.studentController = controller;
        initializePanel(); // Initialize form elements
        initializeFormLayout(); // Setup form layout
        initializeTableLayout(); // Setup table layout
        refreshTable(); // Refresh table data
    }

    /**
     * override setupForm method from BasePanel class to setup form elements and add
     * them to the form layout
     */
    @Override
    protected void setupForm() {
        // Setup form elements

        idField = new TextField();
        idField.setEditable(false);
        nameField = new TextField();
        emailField = new TextField();

        addButton = new Button("Add Student");
        updateButton = new Button("Update Student");
        deleteButton = new Button("Delete Student");
        clearButton = new Button("Clear Selection");

        // set the actions for the buttons
        addButton.setOnAction(e -> addStudent());
        updateButton.setOnAction(e -> updateStudent());
        deleteButton.setOnAction(e -> deleteStudent());
        clearButton.setOnAction(e -> clearSelection());

        // Add form elements to the form layout
        form.setVgap(10);
        form.setHgap(10);
        form.setPadding(new Insets(20));
        form.add(new Label("ID:"), 0, 0);
        form.add(idField, 1, 0);
        form.add(new Label("Name:"), 0, 1);
        form.add(nameField, 1, 1);
        form.add(new Label("Email:"), 0, 2);
        form.add(emailField, 1, 2);
        form.add(addButton, 0, 3);
        form.add(updateButton, 1, 3);
        form.add(deleteButton, 2, 3);
        form.add(clearButton, 3, 3);
    }

    /**
     * override setupTable method from BasePanel class to setup table columns and
     * add them to the table view
     */
    @Override
    protected void setupTable() {
        addTableColumn("ID", "id");
        addTableColumn("Name", "name");
        addTableColumn("Email", "email");
        table.setOnMouseClicked(e -> selectStudent());
    }

    /**
     * override refreshTable method from BasePanel class to refresh the table data
     */
    @Override
    protected void refreshTable() {
        table.getItems().setAll(studentController.getStudents());
    }

    /**
     * Clear the selection
     */
    private void clearSelection() {
        table.getSelectionModel().clearSelection();
        idField.clear();
        nameField.clear();
        emailField.clear();
    }

    /**
     * Add a student
     */
    private void addStudent() {
        if (!validateInput())
            return; // validate the input
        Student newStudent = new Student(nameField.getText(), emailField.getText());
        studentController.addStudent(newStudent);
        refreshStudentTable();
    }

    /**
     * Update a student
     */
    private void updateStudent() {
        Student selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            // show an alert if no student is selected
            ValidationUtils.showAlert("Please select a student to update.");
            return;
        }
        if (!validateInput()) // validate the input
            return;
        selected.setName(nameField.getText());
        selected.setEmail(emailField.getText());
        studentController.updateStudent(selected);
        refreshStudentTable();
    }

    /**
     * Delete a student
     */
    private void deleteStudent() {
        Student selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            // show an alert if no student is selected
            ValidationUtils.showAlert("Please select a student to delete.");
            return;
        }
        if (ValidationUtils.confirmAction("Are you sure you want to delete this student?")) {
            // confirm the action
            studentController.deleteStudent(selected);
            refreshStudentTable();
        }
    }

    /**
     * Validate the input
     * 
     * @return true if the input is valid, false otherwise
     */
    private boolean validateInput() {
        if (!ValidationUtils.isNotEmpty(nameField.getText())) {
            // show an alert if the name is empty
            ValidationUtils.showAlert("Name cannot be empty.");
            return false;
        }
        if (!ValidationUtils.isValidEmail(emailField.getText())) {
            // show an alert if the email is not valid
            ValidationUtils.showAlert("Invalid email format.");
            return false;
        }
        return true;
    }

    /**
     * Select a student
     */
    private void selectStudent() {
        Student selected = table.getSelectionModel().getSelectedItem();
        if (selected != null) {
            // if a student is selected, set the form fields to the student's data
            idField.setText(String.valueOf(selected.getId()));
            nameField.setText(selected.getName());
            emailField.setText(selected.getEmail());
        }
    }

    /**
     * Refresh the student table
     */
    private void refreshStudentTable() {
        table.getItems().setAll(studentController.getStudents());
    }
}
