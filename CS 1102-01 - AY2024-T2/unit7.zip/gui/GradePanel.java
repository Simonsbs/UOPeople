package unit7.gui;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.Slider;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import unit7.controllers.GradeController;
import unit7.models.Course;
import unit7.models.Grade;
import unit7.models.Student;
import unit7.utils.ValidationUtils;

/**
 * Grade panel class - represents a grade panel with form and table layout and
 * design and functionality
 */
public class GradePanel extends BasePanel<Grade> {
    private GradeController gradeController;
    private ComboBox<Student> studentComboBox;
    private ComboBox<Course> courseComboBox;

    private Button registerButton;

    /**
     * Constructor for GradePanel
     * 
     * @param controller the grade controller
     */
    public GradePanel(GradeController controller) {
        this.gradeController = controller;
        initializePanel(); // Initialize form elements
        initializeFormLayout(); // Setup form layout
        initializeTableLayout(); // Setup table layout
        refreshTable(); // Refresh table data
    }

    /**
     * override setupForm method from BasePanel class to setup form elements and add
     * them to the form layout
     */
    @Override
    protected void setupForm() {
        studentComboBox = new ComboBox<>(gradeController.getStudents());
        courseComboBox = new ComboBox<>(gradeController.getCourses());

        // setup the cell factory for the combo box to display the name of the student
        studentComboBox.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(Student student, boolean empty) {
                super.updateItem(student, empty);
                setText(empty ? "" : student.getName());
            }
        });

        // setup the button cell for the combo box to display the name of the student
        studentComboBox.setButtonCell(new ListCell<Student>() {
            @Override
            protected void updateItem(Student student, boolean empty) {
                super.updateItem(student, empty);
                setText(empty ? "" : student.getName());
            }
        });

        // setup the cell factory for the combo box to display the name of the course
        courseComboBox.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(Course course, boolean empty) {
                super.updateItem(course, empty);
                setText(empty ? "" : course.getCourseName());
            }
        });

        // setup the button cell for the combo box to display the name of the course
        courseComboBox.setButtonCell(new ListCell<Course>() {
            @Override
            protected void updateItem(Course course, boolean empty) {
                super.updateItem(course, empty);
                setText(empty ? "" : course.getCourseName());
            }
        });

        // setup the register button
        registerButton = new Button("Register Student");
        registerButton.setOnAction(e -> registerStudentToCourse());
        form.add(registerButton, 0, 3);

        // Add form elements to the form layout
        form.setVgap(10);
        form.setHgap(10);
        form.setPadding(new Insets(20));
        form.add(new Label("Student:"), 0, 0);
        form.add(studentComboBox, 1, 0);
        form.add(new Label("Course:"), 0, 1);
        form.add(courseComboBox, 1, 1);

    }

    /**
     * override setupTable method from BasePanel class to setup table columns and
     * add them to the table view
     */
    private void registerStudentToCourse() {
        Student selectedStudent = studentComboBox.getValue();
        Course selectedCourse = courseComboBox.getValue();

        if (selectedStudent == null || selectedCourse == null) {
            // show an alert if the user did not select a student or a course
            ValidationUtils.showAlert("Please select both a student and a course.");
            return;
        }

        if (selectedStudent != null && selectedCourse != null) {
            if (gradeController.isStudentRegisteredForCourse(selectedStudent, selectedCourse)) {
                // show an alert if the student is already registered for the course
                ValidationUtils.showAlert("Student is already registered for this course.");
            } else {
                // register the student for the course
                gradeController.registerStudentForCourse(selectedStudent, selectedCourse);
                refreshTable();
            }
        }
    }

    /**
     * override setupTable method from BasePanel class to setup table columns and
     * add them to the table view
     */
    @Override
    protected void setupTable() {
        // Setup table columns

        // setup the student name column
        TableColumn<Grade, String> studentNameColumn = new TableColumn<>("Student");
        studentNameColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().getStudent().getName()));

        // setup the course name column
        TableColumn<Grade, String> courseNameColumn = new TableColumn<>("Course");
        courseNameColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().getCourse().getCourseName()));

        // setup the grade column
        TableColumn<Grade, Integer> gradeColumn = new TableColumn<>("Grade");
        gradeColumn.setCellValueFactory(new PropertyValueFactory<>("grade"));

        // setup the slider column to set the grade
        TableColumn<Grade, Void> sliderCol = new TableColumn<>("Set Grade");
        sliderCol.setCellFactory(col -> new TableCell<Grade, Void>() {
            private final Slider slider = new Slider(0, 100, 0);
            private final Label label = new Label("");

            {
                // update the grade when the slider value changes
                slider.valueProperty().addListener((obs, oldval, newVal) -> {
                    Grade grade = getTableView().getItems().get(getIndex());
                    if (grade != null) {
                        // update the grade
                        grade.setGrade(newVal.intValue());
                        label.setText(grade.fullGradeString());
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                // update the slider value when the grade changes
                super.updateItem(item, empty);
                if (empty || getIndex() < 0 || getIndex() >= getTableView().getItems().size()) {
                    // if the grade is null, set the graphic to null
                    setGraphic(null);
                } else {
                    // set the graphic to the slider and label
                    Grade grade = getTableView().getItems().get(getIndex());
                    slider.setValue(grade != null ? grade.getGrade() : 0);

                    label.setText(grade.fullGradeString());
                    setGraphic(new HBox(10, slider, label));
                }
            }
        });

        // setup the action column to unregister a student from a course
        TableColumn<Grade, Void> actionCol = new TableColumn<>("Action");
        actionCol.setCellFactory(col -> new TableCell<Grade, Void>() {
            private final Button btn = new Button("Unregister");

            // set the action for the button
            {
                btn.setOnAction((ActionEvent event) -> {
                    Grade grade = getTableView().getItems().get(getIndex());
                    if (grade != null
                            && ValidationUtils.confirmAction(
                                    "Are you sure you want to unregister " + grade.getStudent().getName() + " from "
                                            + grade.getCourse().getCourseName() + "?")) {
                        // unregister the student from the course
                        gradeController.deleteGrade(grade);
                        refreshTable();
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    // if the grade is null, set the graphic to null
                    setGraphic(null);
                } else {
                    // set the graphic to the button
                    setGraphic(btn);
                }
            }
        });

        // Add columns to the table view
        table.getColumns().add(studentNameColumn);
        table.getColumns().add(courseNameColumn);
        table.getColumns().add(gradeColumn);
        table.getColumns().add(actionCol);
        table.getColumns().add(sliderCol);
    }

    /**
     * override refreshTable method from BasePanel class to refresh table data
     */
    @Override
    protected void refreshTable() {
        table.getItems().setAll(gradeController.getGrades());
    }
}
