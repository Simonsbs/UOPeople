package unit7.gui;

import java.util.Random;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import unit7.controllers.StudentController;
import unit7.models.Course;
import unit7.models.Grade;
import unit7.models.Student;
import unit7.controllers.CourseController;
import unit7.controllers.GradeController;

/**
 * Main frame class - represents the main frame of the application with tabs for
 * each panel this is also the entry point of the application
 */
public class MainFrame extends Application {

    /**
     * Override start method from Application class to setup the primary stage
     */
    @Override
    public void start(Stage primaryStage) {
        // Instantiate controllers
        StudentController studentController = new StudentController();
        CourseController courseController = new CourseController();
        GradeController gradeController = new GradeController();

        // Call functions to populate data
        seedData(studentController, courseController, gradeController);

        // Create tabs for each panel
        TabPane tabPane = new TabPane();

        // Create tabs for each panel
        Tab studentTab = new Tab("Students", new StudentPanel(studentController));
        Tab courseTab = new Tab("Courses", new CoursePanel(courseController));
        Tab gradeTab = new Tab("Grades", new GradePanel(gradeController));

        tabPane.getTabs().addAll(studentTab, courseTab, gradeTab);

        // Setup the primary stage
        BorderPane root = new BorderPane();
        root.setCenter(tabPane);

        // Create the scene and set the primary stage
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setTitle("Student Management System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Seed data for the application
     * 
     * @param studentController the student controller
     * @param courseController  the course controller
     * @param gradeController   the grade controller
     */
    private void seedData(StudentController studentController, CourseController courseController,
            GradeController gradeController) {
        // Adding Students
        studentController.addStudent(new Student("Luke Skywalker", "luke.skywalker@galaxyfarfaraway.com"));
        studentController.addStudent(new Student("Ellen Ripley", "ellen.ripley@nostromo.space"));
        studentController.addStudent(new Student("Sarah Connor", "sarah.connor@skynetdefeated.net"));
        studentController.addStudent(new Student("Jean-Luc Picard", "jeanluc.picard@enterprise.space"));
        studentController.addStudent(new Student("Kathryn Janeway", "kathryn.janeway@voyager.space"));

        // Adding Courses
        courseController.addCourse(new Course("Interstellar Navigation"));
        courseController.addCourse(new Course("Xenobiology"));
        courseController.addCourse(new Course("Advanced Robotics"));
        courseController.addCourse(new Course("Temporal Mechanics"));
        courseController.addCourse(new Course("Quantum Computing"));

        // Assigning random grades to each student for each course
        Random random = new Random();
        for (Student student : studentController.getStudents()) {
            for (Course course : courseController.getCourses()) {

                Grade newGrade = gradeController.registerStudentForCourse(student, course);

                // Randomly assign a grade to the student for the course values 10-100
                int randomGrade = random.nextInt(91) + 10;

                if (random.nextBoolean()) {
                    // 50% chance of assigning a grade to the student for the course
                    // the remaining 50% of the time the grade will be 0
                    newGrade.setGrade(randomGrade);
                }
            }
        }
    }

    /**
     * Entry point of the application
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}