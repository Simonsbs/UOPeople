package unit7.utils;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;

/**
 * ValidationUtils class - contains utility methods for validation
 */
public class ValidationUtils {

    /**
     * Check if a text is empty (null or empty string)
     * 
     * @param text the text
     * @return true if the text is empty, false otherwise
     */
    public static boolean isNotEmpty(String text) {
        return text != null && !text.trim().isEmpty();
    }

    /**
     * Check if an email is valid (has the correct format)
     * 
     * @param email the email
     * @return true if the email is valid, false otherwise
     */
    public static boolean isValidEmail(String email) {
        // Source:
        // https://howtodoinjava.com/java/regex/java-regex-validate-email-address/
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return isNotEmpty(email) && email.matches(emailRegex);
    }

    /**
     * Show an alert with a message
     * 
     * @param message the message
     */
    public static void showAlert(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Confirm an action with a message and return the result
     * 
     * @param message the message
     * @return true if the action is confirmed, false otherwise
     */
    public static boolean confirmAction(String message) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(message);
        return alert.showAndWait().filter(response -> response == ButtonType.OK).isPresent();
    }
}
