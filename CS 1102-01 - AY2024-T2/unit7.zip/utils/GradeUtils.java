package unit7.utils;

/**
 * GradeUtils class - contains utility methods for grades
 */
public class GradeUtils {
    /**
     * Convert a grade to a letter grade
     * 
     * @param grade the grade
     * @return the letter grade
     */
    public static String GradeToLetter(Integer grade) {
        if (grade == 0) {
            return "Not graded yet";
        } else if (grade >= 90) {
            return "A";
        } else if (grade >= 80) {
            return "B";
        } else if (grade >= 70) {
            return "C";
        } else if (grade >= 60) {
            return "D";
        } else {
            return "F";
        }
    }
}