package unit7.models;

/**
 * Student model class
 */
public class Student extends BaseEntity {
    private String name;
    private String email;

    /**
     * Constructor for Student
     * 
     * @param name  the name of the student
     * @param email the email of the student
     */
    public Student(String name, String email) {
        this.name = name;
        this.email = email;
    }

    /**
     * Get the name of the student
     * 
     * @return the name of the student
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name of the student
     * 
     * @param name the name of the student
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get the email of the student
     * 
     * @return the email of the student
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the email of the student
     * 
     * @param email the email of the student
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
