package unit7.models;

/**
 * Course model class
 */
public class Course extends BaseEntity {
    private String courseName;

    /**
     * Constructor for Course
     * 
     * @param courseName the name of the course
     */
    public Course(String courseName) {
        this.courseName = courseName;
    }

    /**
     * Constructor for Course
     * 
     * @param id         the id of the course
     * @param courseName the name of the course
     */
    public Course(int id, String courseName) {
        this.setId(id);
        this.courseName = courseName;
    }

    /**
     * Get the name of the course
     * 
     * @return the name of the course
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     * Set the name of the course
     * 
     * @param courseName the name of the course
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
