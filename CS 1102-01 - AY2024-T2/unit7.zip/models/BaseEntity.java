package unit7.models;

/**
 * Base model class - represents a base model with shared properties and methods
 */
public abstract class BaseEntity {
    protected int id;

    /**
     * Get the id of the model
     * 
     * @return the id of the model
     */
    public int getId() {
        return id;
    }

    /**
     * Set the id of the model
     * 
     * @param id the id of the model
     */
    public void setId(int id) {
        this.id = id;
    }
}
