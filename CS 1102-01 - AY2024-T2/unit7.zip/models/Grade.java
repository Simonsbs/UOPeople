package unit7.models;

import unit7.utils.GradeUtils;

/**
 * Grade model class - represents a grade and course for a student
 */
public class Grade {
    private Student student;
    private Course course;
    private Integer grade;

    /**
     * Constructor for Grade
     * 
     * @param student the student
     * @param course  the course
     */
    public Grade(Student student, Course course) {
        this.student = student;
        this.course = course;
        grade = 0;
    }

    /**
     * Get the student
     * 
     * @return the student
     */
    public Student getStudent() {
        return student;
    }

    /**
     * Set the student
     * 
     * @param student the student
     */
    public void setStudent(Student student) {
        this.student = student;
    }

    /**
     * Get the course
     * 
     * @return the course
     */
    public Course getCourse() {
        return course;
    }

    /**
     * Set the course
     * 
     * @param course the course
     */
    public void setCourse(Course course) {
        this.course = course;
    }

    /**
     * Get the grade value (0-100)
     * 
     * @return the grade value (0-100)
     */
    public Integer getGrade() {
        return grade;
    }

    /**
     * Set the grade value (0-100)
     * 
     * @param grade the grade value (0-100)
     */
    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    /**
     * Get the letter grade (A, B, C, D, F)
     * 
     * @return the letter grade (A, B, C, D, F)
     */
    public String getLetterGrade() {
        return GradeUtils.GradeToLetter(grade);
    }

    /**
     * Get the full grade string (grade + letter grade)
     * 
     * @return the full grade string
     */
    public String fullGradeString() {
        if (grade == 0) {
            return "No grade yet";
        } else {
            return grade.toString() + " (" + getLetterGrade() + ")";
        }
    }
}
