package unit7.controllers;

import unit7.models.Student;
import unit7.models.Course;
import unit7.models.Grade;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Base controller class - represents a base controller with shared properties
 * and methods
 */
public abstract class BaseController {
    // shared data - ObservableList is a list that enables listeners to track
    // changes when they occur
    protected static final ObservableList<Student> students = FXCollections.observableArrayList();
    protected static final ObservableList<Course> courses = FXCollections.observableArrayList();
    protected static final ObservableList<Grade> grades = FXCollections.observableArrayList();

    /**
     * Get the grades list
     * 
     * @return the grades list
     */
    public ObservableList<Grade> getGrades() {
        return grades;
    }

    /**
     * Get the students list
     * 
     * @return the students list
     */
    public ObservableList<Student> getStudents() {
        return students;
    }

    /**
     * Get the courses list
     * 
     * @return the courses list
     */
    public ObservableList<Course> getCourses() {
        return courses;
    }
}
