package unit7.controllers;

import unit7.models.Grade;
import unit7.models.Student;
import unit7.models.Course;
import javafx.collections.ObservableList;
import java.util.function.Consumer;

/**
 * Grade controller class
 */
public class GradeController extends BaseController {

    // onUpdate is a callback function that is called when the grades list is
    // updated
    private Consumer<ObservableList<Grade>> onUpdate;

    /**
     * register the onUpdate callback function
     */
    public void setOnUpdate(Consumer<ObservableList<Grade>> onUpdate) {
        this.onUpdate = onUpdate;
    }

    /**
     * check if a student is registered for a course
     * 
     * @return the if the student is registered for the course
     */
    public boolean isStudentRegisteredForCourse(Student student, Course course) {
        // find the course in the list and replace it with the updated course
        for (Grade g : grades) {
            // if the id of the course in the list matches the id of the updated course
            if (g.getStudent().equals(student) && g.getCourse().equals(course)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Register a student to a course
     * 
     * @param student the student
     * @param course  the course
     * @return the grade object
     */
    public Grade registerStudentForCourse(Student student, Course course) {
        // find the course in the list and replace it with the updated course
        if (!isStudentRegisteredForCourse(student, course)) {
            Grade newGrade = new Grade(student, course);

            grades.add(newGrade);

            if (onUpdate != null) {
                // call the onUpdate callback function
                onUpdate.accept(grades);
            }

            return newGrade;
        }
        return null;
    }

    /**
     * set the grade for a student in a course
     * 
     * @param student    the student
     * @param course     the course
     * @param gradeValue the grade value
     */
    public void setGrade(Student student, Course course, Integer gradeValue) {
        for (Grade g : grades) {
            if (g.getStudent().equals(student) && g.getCourse().equals(course)) {
                g.setGrade(gradeValue);

                if (onUpdate != null) {
                    onUpdate.accept(grades);
                }
                return;
            }
        }

        registerStudentForCourse(student, course);
        setGrade(student, course, gradeValue);
    }

    /**
     * Remove the grade from the list
     * 
     * @param grade the grade to remove
     */
    public void deleteGrade(Grade grade) {
        Grade toRemove = null;
        for (Grade g : grades) {
            if (g.getStudent().equals(grade.getStudent()) && g.getCourse().equals(grade.getCourse())) {
                toRemove = g;
                break;
            }
        }
        if (toRemove != null) {
            grades.remove(toRemove);
        }

        if (onUpdate != null) {
            onUpdate.accept(grades);
        }
    }
}
