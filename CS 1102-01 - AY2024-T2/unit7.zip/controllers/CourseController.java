package unit7.controllers;

import unit7.models.Course;
import javafx.collections.ObservableList;
import java.util.function.Consumer;

/**
 * Course controller class
 */
public class CourseController extends BaseController {

    // onUpdate is a callback function that is called when the courses list is
    // updated
    private Consumer<ObservableList<Course>> onUpdate;

    /**
     * register the onUpdate callback function
     */
    public void setOnUpdate(Consumer<ObservableList<Course>> onUpdate) {
        this.onUpdate = onUpdate;
    }

    /**
     * add a course to the courses list
     * 
     * @param course the course to add
     */
    public void addCourse(Course course) {
        int maxId = 0;
        // find the max id in the list
        for (Course c : courses) {
            if (c.getId() > maxId) {
                maxId = c.getId();
            }
        }
        // set the id of the new course to the maxid + 1
        course.setId(maxId + 1);
        courses.add(course);
        if (onUpdate != null) {
            onUpdate.accept(courses);
        }
    }

    /**
     * Update the course
     * 
     * @param updatedCourse the updated course
     */
    public void updateCourse(Course updatedCourse) {
        // find the course in the list and replace it with the updated course
        for (int i = 0; i < courses.size(); i++) {
            // if the id of the course in the list matches the id of the updated course
            if (courses.get(i).getId() == updatedCourse.getId()) {
                // replace the course in the list with the updated course
                courses.set(i, updatedCourse);
                if (onUpdate != null) {
                    // call the onUpdate callback function
                    onUpdate.accept(courses);
                }
                return;
            }
        }
    }

    /**
     * Remove a course from the courses list
     * 
     * @param course the course to remove
     */
    public void deleteCourse(Course course) {
        // remove the course from the list
        courses.removeIf(c -> c.getId() == course.getId());
        if (onUpdate != null) {
            // call the onUpdate callback function
            onUpdate.accept(courses);
        }
    }
}
