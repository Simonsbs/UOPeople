package unit7.controllers;

import unit7.models.Student;
import javafx.collections.ObservableList;
import java.util.function.Consumer;

/**
 * Student controller class
 */
public class StudentController extends BaseController {

    // onUpdate is a callback function that is called when the students list is
    // updated
    private Consumer<ObservableList<Student>> onUpdate;

    /**
     * Constructor for StudentController
     */
    public void setOnUpdate(Consumer<ObservableList<Student>> onUpdate) {
        this.onUpdate = onUpdate;
    }

    /**
     * Get the students
     * 
     * @return the students
     */
    public void addStudent(Student student) {
        int maxId = 0;
        // find the max id in the list
        for (Student s : students) {
            if (s.getId() > maxId) {
                maxId = s.getId();
            }
        }
        // set the id of the new student to the maxid + 1
        student.setId(maxId + 1);
        students.add(student);
        if (onUpdate != null) {
            // call the onUpdate callback function
            onUpdate.accept(students);
        }
    }

    /**
     * Update the student
     * 
     * @param updatedStudent the updated student
     */
    public void updateStudent(Student updatedStudent) {
        // find the student in the list and replace it with the updated student
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId() == updatedStudent.getId()) {
                students.set(i, updatedStudent);
                if (onUpdate != null) {
                    // call the onUpdate callback function
                    onUpdate.accept(students);
                }
                return;
            }
        }
    }

    /**
     * Delete the student
     * 
     * @param student the student to delete
     */
    public void deleteStudent(Student student) {
        // remove the student from the list
        students.removeIf(s -> s.getId() == student.getId());
        if (onUpdate != null) {
            onUpdate.accept(students);
        }
    }
}
