// Employee.java

class Employee {
    private String name;
    private int age;
    private String department;
    private double salary;

    /**
     * Constructor for Employee class
     * 
     * @param name       name of the employee
     * @param age        age of the employee
     * @param department department of the employee
     * @param salary     salary of the employee
     */
    public Employee(String name, int age, String department, double salary) {
        this.name = name;
        this.age = age;
        this.department = department;
        this.salary = salary;
    }

    /**
     * Constructor for Employee class that takes an array of strings as input
     * 
     * @param data array of strings containing the employee data
     */
    public Employee(String[] data) {
        this.name = data[0];
        this.age = Integer.parseInt(data[1]);
        this.department = data[2];
        this.salary = Double.parseDouble(data[3]);
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return salary;
    }
}
