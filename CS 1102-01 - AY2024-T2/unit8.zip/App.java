import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;
import java.util.Scanner;

public class App {
    private static List<Employee> employees = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    // Function interface to map an employee to a string (name - department)
    private static Function<Employee, String> nameAndDepartment = employee -> "* " + employee.getName() + " - "
            + employee.getDepartment() + "\n";

    /**
     * Main method of the application the main entry point of the application
     * 
     * @param args
     */
    public static void main(String[] args) {
        ReadData("D:\\Projects\\Java\\unit8\\bin\\employees.csv");

        // Main loop - keep looping until user enters E
        while (true) {
            System.out.println("Select an option:");
            System.out.println("1 - Employee Details");
            System.out.println("2 - Average Salary");
            System.out.println("3 - Filter Employees");
            System.out.println("E - Exit");
            System.out.println("Enter your choice: ");
            String choice = scanner.next(); // Read user input

            switch (choice.toUpperCase()) {
                case "1":
                    PrintEmployeeDetails();
                    break;
                case "2":
                    CalculateAverageSalary();
                    break;
                case "3":
                    FilterEmployees();
                    break;
                case "E":
                    System.out.println("Bye bye...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            hr();
        }
    }

    /**
     * request user input for minimum age and salary and filter employees based on
     * the input values and print the filtered employees
     */
    private static void FilterEmployees() {
        int minAge = getIntInput("Enter minimum age: ");
        double minSalary = getDoubleInput("Enter minimum salary: ");

        List<Employee> filteredEmployees = employees
                .stream() // Creating a stream from the list of employees
                .filter(employee -> employee.getAge() > minAge) // Filtering employees with age > minAge
                .filter(employee -> employee.getSalary() > minSalary) // Filtering employees with salary > minSalary
                .toList(); // Collecting the stream into a list object

        hr();

        // Printing the filtered employees
        System.out.println("Filtered Employees (Age > " + minAge + ") and (Salary > " + minSalary + "):");
        for (Employee employee : filteredEmployees) {
            System.out.println("* " + employee.getName() + " - " + employee.getAge());
        }
    }

    /**
     * Calculate the average salary of all employees and print the result
     */
    private static void CalculateAverageSalary() {
        double averageSalary = employees
                .stream() // Creating a stream from the list of employees
                .mapToDouble(Employee::getSalary) // Mapping each employee to a double using the getSalary method
                .average() // Calculating the average of all salaries
                .orElse(0); // If the stream is empty, return 0

        hr();

        // Printing the average salary formatted to 2 decimal places
        System.out.printf("Average Salary: %.2f\n", averageSalary);
    }

    /**
     * Print the details of all employees in the list
     */
    private static void PrintEmployeeDetails() {
        List<String> employeeDetails = employees
                .stream() // Creating a stream from the list of employees
                .map(nameAndDepartment) // Mapping each employee to a string using the function interface
                .toList(); // Collecting the stream into a list object

        hr();

        System.out.println("Employee Details (Name - Department): ");
        for (String employeeDetail : employeeDetails) {
            System.out.print(employeeDetail);
        }
    }

    /**
     * Read data from a CSV file and populate the employees list
     * 
     * @param fileName the name and path of the CSV file
     */
    private static void ReadData(String fileName) {
        Path path = Paths.get(fileName);

        // Reading CSV file using streams using try-with-resources
        try (Stream<String> lines = Files.lines(path, StandardCharsets.UTF_8)) {
            employees = lines
                    .skip(1) // Skipping CSV header
                    .map(line -> line.split(",")) // Splitting each line into an array of strings
                    .map(data -> new Employee(data)) // Creating an Employee object from the array of strings
                    .toList(); // Collecting the stream into a list object
        } catch (IOException e) {
            // Log error to console
            System.out.println("Error reading a line in file: " + fileName);
            System.out.println(e.getMessage());
            e.printStackTrace();
            return;
        }
    }

    /**
     * Print a horizontal line to the console
     */
    private static void hr() {
        System.out.println("--------------------------------------------------");
    }

    /**
     * Get an integer input from the user and validate the input
     * 
     * @param prompt the prompt to display to the user
     * @return the integer input from the user
     */
    private static int getIntInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            // Check if the input is an integer and if not, display an error message and
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.next();
                continue;
            }
            return scanner.nextInt();
        }
    }

    /**
     * Get a double input from the user and validate the input
     * 
     * @param prompt the prompt to display to the user
     * @return the double input from the user
     */
    private static double getDoubleInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            // Check if the input is a double and if not, display an error message and
            if (!scanner.hasNextDouble()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }
            return scanner.nextDouble();
        }
    }
}
