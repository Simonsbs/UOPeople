package catalog;

/**
 * Enum representing the type of library item.
 */
public enum ItemType {
    BOOK,
    DVD,
    MAGAZINE;
}